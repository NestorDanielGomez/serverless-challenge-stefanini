export const MOCK_ID = "695728d3-53a0-4c19-88ec-770ea239219c"
export const MOCK_DTO = { dni: 29054384, edad: 40, nombre: "nestor", cargo: "pesado" }
export const MOCK_RESPONSE = { id: MOCK_ID, dni: 29054384, edad: 40, nombre: "nestor", cargo: "pesado" }
export const MOCK_MSG_DELETED = `Employee with Id:${MOCK_ID} and Name:${MOCK_DTO.nombre} deleted`